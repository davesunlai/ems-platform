"""Databázové dotazy pro API (TimescaleDB / PostgreSQL přes asyncpg)."""
from __future__ import annotations

import os

_pool = None


async def get_pool():
    global _pool
    if _pool is None:
        import asyncpg
        dsn = os.getenv("EMS_DB_DSN", "postgresql://ems:ems@timescaledb:5432/ems")
        _pool = await asyncpg.create_pool(dsn, min_size=1, max_size=8)
    return _pool


async def close_pool() -> None:
    global _pool
    if _pool is not None:
        await _pool.close()
        _pool = None


async def list_devices() -> list[dict]:
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT DISTINCT device_id FROM samples ORDER BY device_id"
        )
    return [{"device_id": r["device_id"]} for r in rows]


async def latest_for_device(device_id: str) -> list[dict]:
    """Poslední hodnota každé veličiny daného zařízení."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """
            SELECT DISTINCT ON (metric) metric, value, unit, quality, time
            FROM samples
            WHERE device_id = $1
            ORDER BY metric, time DESC
            """,
            device_id,
        )
    return [dict(r) for r in rows]


async def history(device_id: str, metric: str, minutes: int = 360) -> list[dict]:
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """
            SELECT time, value
            FROM samples
            WHERE device_id = $1 AND metric = $2
              AND time > now() - ($3 || ' minutes')::interval
            ORDER BY time
            """,
            device_id, metric, str(minutes),
        )
    return [{"time": r["time"].isoformat(), "value": r["value"]} for r in rows]
