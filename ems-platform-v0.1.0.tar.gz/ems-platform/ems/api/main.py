"""REST API nad uloženou telemetrií.

Spuštění:
    EMS_DB_DSN=postgresql://ems:ems@localhost:5432/ems \\
        uvicorn ems.api.main:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from . import db

app = FastAPI(title="EMS Platform API", version="0.1.0")

# Pro pilotní web na jiném portu. V produkci omezit na konkrétní origin.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET"],
    allow_headers=["*"],
)


@app.get("/api/health")
async def health() -> dict:
    return {"status": "ok"}


@app.get("/api/devices")
async def devices() -> list[dict]:
    return await db.list_devices()


@app.get("/api/devices/{device_id}/latest")
async def latest(device_id: str) -> dict:
    rows = await db.latest_for_device(device_id)
    if not rows:
        raise HTTPException(status_code=404, detail="Zařízení nemá data")
    metrics = {
        r["metric"]: {
            "value": r["value"],
            "unit": r["unit"],
            "quality": r["quality"],
            "time": r["time"].isoformat(),
        }
        for r in rows
    }
    return {"device_id": device_id, "metrics": metrics}


@app.get("/api/devices/{device_id}/history")
async def device_history(device_id: str, metric: str, minutes: int = 360) -> dict:
    points = await db.history(device_id, metric, minutes)
    return {"device_id": device_id, "metric": metric, "points": points}


@app.on_event("shutdown")
async def _shutdown() -> None:
    await db.close_pool()
