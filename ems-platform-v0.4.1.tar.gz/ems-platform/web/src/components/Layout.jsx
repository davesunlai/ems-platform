import { NavLink, Outlet } from "react-router-dom";
import { useAuth } from "../auth";

export default function Layout() {
  const { user, logout, has } = useAuth();
  return (
    <>
      <header className="topbar">
        <div className="brand">
          <span className="dot" />
          <b>EMS Platform</b>
          <span>pilot</span>
        </div>
        <nav className="nav">
          <NavLink to="/" end>Dashboard</NavLink>
          {has("control") && <NavLink to="/control">Řízení</NavLink>}
          {has("admin") && <NavLink to="/modules">Moduly</NavLink>}
          {has("admin") && <NavLink to="/users">Uživatelé</NavLink>}
        </nav>
        <div className="spacer" />
        <div className="userbox">
          <span>{user?.username}</span>
          <span className="role">{user?.role}</span>
          <button className="btn" onClick={logout}>Odhlásit</button>
        </div>
      </header>
      <Outlet />
    </>
  );
}
