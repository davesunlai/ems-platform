"""EMS Platform — univerzální energy management napříč portfoliem."""
__version__ = "0.5.0"
