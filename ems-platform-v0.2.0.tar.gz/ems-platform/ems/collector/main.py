"""Kolektor: periodicky čte z adaptérů a zapisuje do sinku.

Spuštění:
    EMS_DEVICES=devices.yaml EMS_SINK=stdout python -m ems.collector.main

Odolnost: chyba jednoho zařízení nezhodí celý kolektor — jen se zaloguje
a pokračuje se dál. To je základní stavební kámen pozdější HA.
"""
from __future__ import annotations

import asyncio
import logging
import os
import signal

from ems.core.model import reading_to_samples
from .config import build_adapter, build_sink, load_devices

logging.basicConfig(
    level=os.getenv("EMS_LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("ems.collector")

POLL_INTERVAL = float(os.getenv("EMS_POLL_INTERVAL", "10"))
DEVICES_PATH = os.getenv("EMS_DEVICES", "devices.yaml")


async def poll_device(adapter, sink) -> None:
    try:
        reading = await adapter.read()
        await sink.write(reading_to_samples(reading))
    except Exception as exc:  # jedno zařízení nesmí shodit celek
        logger.warning("Čtení '%s' selhalo: %s", getattr(adapter, "device_id", "?"), exc)


async def run() -> None:
    devices = load_devices(DEVICES_PATH)
    if not devices:
        logger.error("Žádná zařízení v %s", DEVICES_PATH)
        return

    sink = build_sink()
    adapters = []
    for dev in devices:
        adapter = build_adapter(dev)
        try:
            await adapter.connect()
            adapters.append(adapter)
            logger.info("Zařízení připraveno: %s (%s, adaptér=%s)", dev.id, dev.type.value, dev.adapter)
        except Exception as exc:
            logger.error("Připojení '%s' selhalo: %s", dev.id, exc)

    if not adapters:
        logger.error("Žádný adaptér se nepřipojil, končím.")
        return

    stop = asyncio.Event()

    def _handle_signal() -> None:
        logger.info("Ukončuji…")
        stop.set()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _handle_signal)
        except NotImplementedError:
            pass  # Windows

    logger.info("Kolektor běží, interval=%ss, zařízení=%d", POLL_INTERVAL, len(adapters))
    try:
        while not stop.is_set():
            await asyncio.gather(*(poll_device(a, sink) for a in adapters))
            try:
                await asyncio.wait_for(stop.wait(), timeout=POLL_INTERVAL)
            except asyncio.TimeoutError:
                pass
    finally:
        for a in adapters:
            await a.close()
        await sink.close()
        logger.info("Kolektor zastaven.")


def main() -> None:
    asyncio.run(run())


if __name__ == "__main__":
    main()
